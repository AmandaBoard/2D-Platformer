using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public GameObject gameManagerObject;
    public GameManager gameManager;

    public AudioManager audioManager;
    //private void Awake(){
    //    audioManager = GameObject.FindGameObjectWithTag("Audiotag").GetComponent<AudioManager>();
    //}
    private int coinValue = 1;
    // Start is called before the first frame update
    void Start()
    {
        gameManagerObject = GameObject.FindWithTag("GameController");
        if(gameManagerObject != null){
            gameManager = gameManagerObject.GetComponent<GameManager>();
        } else {
            Debug.LogError("Game Manager not found :(");
        }
    }

    // Update is called once per frame
    void OnTriggerEnter2D(Collider2D other){
        if(other.CompareTag("Player")){
            if(gameManager != null){
                gameManager.AddScore(coinValue);
                gameObject.SetActive(false);
                // add coin sound effect audioManager.PlaySFX(audioManager.cricket);
            }
        } else {
            
        }
    }

}
