using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;


public class GameManager : MonoBehaviour
{
    public int score = 0;
    static int scoreGoal = 3;
    public EventTrigger.TriggerEvent DeathTrigger;
    public ScoreBar scoreBar;
    AudioSource birdsound;
    
    public GameObject gameOverScreen;
    string sceneName;
    public TextMeshProUGUI ScoreText;
    public TextMeshProUGUI WinText;
    public TextMeshProUGUI HealthText;
    
    public float PlayerHealth = 3f;
    private float CurrentPlayerHealth;


        public void LevelFinish(){
        Debug.Log("Goal Reached.");
        //WinText.enabled = true;
    }

    // Start is called before the first frame update
    void Start()
    {
        birdsound = GetComponent<AudioSource>();
        CurrentPlayerHealth = PlayerHealth;
        score = 0;
        HealthText.text = "Health: " + CurrentPlayerHealth;
        
        // get the current scene so we can reload it when we want to
        sceneName = SceneManager.GetActiveScene().name;
        ScoreText.text = "Score " + score;
        WinText.enabled = false;
    }

    public void PlayerDamaged(){
        CurrentPlayerHealth--;
        birdsound.Play();
        HealthText.text = "Health: " + CurrentPlayerHealth;
    
        if(CurrentPlayerHealth <= 0){
            BaseEventData EventData = new BaseEventData(EventSystem.current);
            this.DeathTrigger.Invoke(EventData);
            CurrentPlayerHealth = PlayerHealth;
            HealthText.text = "Health: " + CurrentPlayerHealth;
        }
    }
     public void AddScore(int value) {
        score++;
        //numCoinsCollected += 1;
        ScoreText.text = "Score " + score;
        if(score >= scoreGoal){
            score = 0;
            UnityEngine.SceneManagement.SceneManager.LoadScene("VictoryScreen");
        }

       // scoreBar.UpdateScoreBar(numCoinsCollected);
        //CheckEndGame();
    }

    // Update is called once per frame
    void Update()
    {
        // makes it so the user can restart the game whenever they want by pressing r
        if( Input.GetKeyDown("r") ){
            //RestartGame();
        }
    }
}

    // Add coin value to score
    //public void AddScore(int value) {
      //  score++;
        //numCoinsCollected += 1;
        //ScoreText.text = "Score " + score;
       // scoreBar.UpdateScoreBar(numCoinsCollected);
        //CheckEndGame();
    //}
      // reload the scene to the original state
    //public void RestartGame() {
    //    SceneManager.LoadScene( sceneName );
    //}