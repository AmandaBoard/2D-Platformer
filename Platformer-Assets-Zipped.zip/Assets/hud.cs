using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Hud : MonoBehaviour
{
    public GameObject hud;
    private bool hudOpen;
    public TextMeshProUGUI hudText;
    private int coins, rubies;
     public GameObject gameManagerObject;
    public GameManager gameManager;

    //private int coinValue = 1;
    // Start is called before the first frame update
    void Start()
    {
        hud.SetActive(false);
        gameManagerObject = GameObject.FindWithTag("GameController");
        if(gameManagerObject != null){
            gameManager = gameManagerObject.GetComponent<GameManager>();

        } else {
            Debug.LogError("Game Manager not found :(");
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Tab)){
            Debug.Log("Escape Pressed");
            if(hudOpen){
                closeHud();
            } else {
                openHud();
            }
        }
    }

    void openHud(){
        hud.SetActive(true);
        Time.timeScale = 0f;
        hudOpen = true;
        //coins = gameManager.GetCoins();
        //rubies = gameManager.GetRubies();
        hudText.SetText("Welcome to your hud \n\n Coins: {0}  Rubies {1}", coins, rubies);
    }
    void closeHud(){
        hud.SetActive(false);
        Time.timeScale = 1f;
        hudOpen = false;

    }
}
