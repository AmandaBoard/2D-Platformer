using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
   public float MoveSpeed = 3f;
   public Transform GroundDetect;

   private bool MovingRight;

}
